<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->date('expenses_date');
            $table->unsignedBigInteger('category_id');
            $table->string('expenses_for', 255);
            $table->decimal('expenses_amount', 10,2);
            $table->integer('expenses_reference')->nullable();
            $table->string('expenses_note', 255)->nullable();
            $table->string('expenses_created_by', 50);
            $table->foreign('category_id')->references('id')->on('expense_categories');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('expenses');
    }
};
