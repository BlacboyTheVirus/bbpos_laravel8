<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvoiceitemController extends Controller
{
    //
}
